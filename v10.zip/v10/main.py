import os
import time

from flask import *
from flask_login import login_user, LoginManager, current_user, login_required, logout_user
from werkzeug.utils import secure_filename

from data import db_session
from data.comms import Comment
from data.msg import Message
from data.news import News
from data.users import User
from forms.comms import *
from forms.msg import *
from forms.news import *
from forms.user import *

db_session.global_init("db/blogs.db")

app = Flask(__name__)
app.config['SECRET_KEY'] = 'meow'

login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route("/<int:prof_id>", methods=['GET', 'POST'])
def index(prof_id):
    session['from_page'] = f'/{prof_id}'
    form = NewsForm()
    commsform = CommsForm()
    db_sess = db_session.create_session()
    comms = db_sess.query(Comment).all()
    prof_user = db_sess.query(User).filter(User.id == prof_id)
    if current_user.is_authenticated:
        news = db_sess.query(News).filter(News.user.has(id=prof_id))
        if form.validate_on_submit():
            attachments = []
            f = request.files['file']
            if f:
                # print(request.files.to_dict(flat=False)['file'])
                files = request.files.to_dict(flat=False)['file']
                for file in files:
                    filename = secure_filename(f'{str(time.time()).replace(".", "-")}.png')
                    attachments.append(filename)
                    # print(filename)
                    file.save('static/attachments/' + filename)
            db_sess = db_session.create_session()
            news = News()
            news.title = form.title.data
            news.content = form.content.data
            news.is_private = form.is_private.data
            news.attach = '|'.join(attachments)
            current_user.news.append(news)
            db_sess.merge(current_user)
            db_sess.commit()
            return redirect(f'/{prof_id}')
        if commsform.validate_on_submit():
            db_sess = db_session.create_session()
            comm = Comment()
            comm.to = commsform.to.data
            comm.content = commsform.content.data
            current_user.comm.append(comm)
            db_sess.merge(current_user)
            db_sess.commit()
            return redirect(f'/{prof_id}')
    else:
        news = db_sess.query(News).filter(News.is_private != True).order_by(News.created_date.desc())
    return render_template("profile.html", news=news, form=form, profile_id=prof_id, profile_user=prof_user,
                           comments=comms, commsform=commsform)


@app.route('/uploader', methods=['GET', 'POST'])
def uploader():
    if request.method == 'POST':
        f = request.files['file']
        # ext = f.filename.split('.')[-1]
        f.save('static/userpics/' + secure_filename(f'{current_user.id}.png'))
        return redirect(f'/{current_user.id}')


@app.route("/", methods=['GET', 'POST'])
@app.route("/feed", methods=['GET', 'POST'])
def feed():
    session['from_page'] = f'/feed'
    form = NewsForm()
    commsform = CommsForm()
    db_sess = db_session.create_session()
    comms = db_sess.query(Comment).all()
    if current_user.is_authenticated:
        news = db_sess.query(News).filter((News.user == current_user) | (News.is_private != True)).order_by(
            News.created_date.desc())
        if form.validate_on_submit():
            attachments = []
            f = request.files['file']
            if f:
                # print(request.files.to_dict(flat=False)['file'])
                files = request.files.to_dict(flat=False)['file']
                for file in files:
                    filename = secure_filename(f'{str(time.time()).replace(".", "-")}.png')
                    attachments.append(filename)
                    # print(filename)
                    file.save('static/attachments/' + filename)
            db_sess = db_session.create_session()
            news = News()
            news.title = form.title.data
            news.content = form.content.data
            news.is_private = form.is_private.data
            news.attach = '|'.join(attachments)
            current_user.news.append(news)
            db_sess.merge(current_user)
            db_sess.commit()
            return redirect('/feed')
        if commsform.validate_on_submit():
            db_sess = db_session.create_session()
            comm = Comment()
            comm.to = commsform.to.data
            comm.content = commsform.content.data
            current_user.comm.append(comm)
            db_sess.merge(current_user)
            db_sess.commit()
            return redirect(f'/feed#{comm.to}')
    else:
        news = db_sess.query(News).filter(News.is_private != True).order_by(News.created_date.desc())
    return render_template("feed.html", news=news, form=form, comments=comms, commsform=commsform)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            about=form.about.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/news', methods=['GET', 'POST'])
@login_required
def add_news():
    form = NewsForm()
    if form.validate_on_submit():
        attachments = []
        f = request.files['file']
        if f:
            # print(request.files.to_dict(flat=False)['file'])
            files = request.files.to_dict(flat=False)['file']
            for file in files:
                filename = secure_filename(f'{str(time.time()).replace(".", "-")}.png')
                attachments.append(filename)
                # print(filename)
                file.save('static/attachments/' + filename)
        db_sess = db_session.create_session()
        news = News()
        news.title = form.title.data
        news.content = form.content.data
        news.is_private = form.is_private.data
        news.attach = '|'.join(attachments)
        current_user.news.append(news)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/feed')
    return render_template('news.html', title='Добавление новости', form=form)


@app.route('/news/delete/<int:id>', methods=['GET', 'POST'])
@login_required
def news_delete(id):
    db_sess = db_session.create_session()
    news = db_sess.query(News).filter(News.id == id, ((News.user == current_user) | current_user.is_admin)).first()
    if news:
        # print(news.attach)
        try:
            for i in news.attach.split('|'):
                os.remove(f'static/attachments/{i}')
        except Exception as e:
            str(e)
        db_sess.delete(news)
        db_sess.commit()
    else:
        # abort(403)
        redirect('/login')
    if session.get('from_page', None) == '/feed':
        return redirect(f'/feed#{id - 1}')
    else:
        return redirect(session.get('from_page', f'/feed#{id - 1}'))


@app.route('/comments/delete/<int:id>', methods=['GET', 'POST'])
@login_required
def comms_delete(id):
    db_sess = db_session.create_session()
    comms = db_sess.query(Comment).filter(Comment.id == id,
                                          ((Comment.user == current_user) | current_user.is_admin)).first()
    if comms:
        db_sess.delete(comms)
        db_sess.commit()
    else:
        # abort(403)
        redirect('/login')
    if session.get('from_page', None) == '/feed':
        return redirect(f'/feed#{comms.to}')
    else:
        return redirect(session.get('from_page', f'/feed#{comms.to}'))


@app.route('/news/like/<int:id>', methods=['GET', 'POST'])
@login_required
def news_like(id):
    db_sess = db_session.create_session()
    news = db_sess.query(News).filter(News.id == id).first()
    if news:
        if news.liked_by:
            if current_user.name not in news.liked_by.split('|'):
                news.liked_by += '|' + current_user.name
        else:
            news.liked_by = current_user.name

        news.likes = len(news.liked_by.split('|'))
        db_sess.commit()
    else:
        # abort(403)
        redirect('/login')
    if session.get('from_page', None) == '/feed':
        return redirect(f'/feed#{id}')
    else:
        return redirect(session.get('from_page', f'/feed#{id}'))


@app.route('/news/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_news(id):
    form = NewsForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        news = db_sess.query(News).filter(News.id == id, ((News.user == current_user) | current_user.is_admin)).first()
        if news:
            form.title.data = news.title
            form.content.data = news.content
            form.is_private.data = news.is_private
        else:
            # abort(403)
            redirect('/login')
    if form.validate_on_submit():
        attachments = []
        f = request.files['file']
        if f:
            # print(request.files.to_dict(flat=False)['file'])
            files = request.files.to_dict(flat=False)['file']
            for file in files:
                filename = secure_filename(f'{str(time.time()).replace(".", "-")}.png')
                attachments.append(filename)
                # print(filename)
                file.save('static/attachments/' + filename)
        db_sess = db_session.create_session()
        news = db_sess.query(News).filter(News.id == id, ((News.user == current_user) | current_user.is_admin)).first()
        if news:
            news.title = form.title.data
            news.content = form.content.data
            news.is_private = form.is_private.data
            try:
                for i in news.attach.split('|'):
                    os.remove(f'static/attachments/{i}')
            except Exception as e:
                str(e)
            news.attach = '|'.join(attachments)
            db_sess.commit()
            if session.get('from_page', None) == '/feed':
                return redirect(f'/feed#{id}')
            else:
                return redirect(session.get('from_page', f'/feed#{id}'))
        else:
            # abort(403)
            redirect('/login')
    return render_template('news.html', title='Редактирование новости', form=form)


@app.route('/msg/<int:to>', methods=['GET', 'POST'])
@login_required
def add_msg(to):
    db_sess = db_session.create_session()
    messages = []
    if current_user.is_authenticated:
        messages = db_sess.query(Message).filter(
            Message.title.like(f'{current_user.id}_{to}') | Message.title.like(f'{to}_{current_user.id}')).order_by(
            Message.created_date.desc())
        # # print(messages)
    form = MsgForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        msg = Message()
        if current_user.id > to:
            msg.title = f'{current_user.id}_{to}'
        else:
            msg.title = f'{to}_{current_user.id}'
        msg.content = form.content.data
        # news.is_private = form.is_private.data
        current_user.msg.append(msg)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect(f'/msg/{to}')
    return render_template('msg.html', title='Добавление новости', form=form, messages=messages)


@app.route('/msg/<int:to>/delete/<int:id>', methods=['GET', 'POST'])
@login_required
def msg_delete(id, to):
    db_sess = db_session.create_session()
    msg = db_sess.query(Message).filter(
        Message.id == id).first()  # ((News.user == current_user) | current_user.is_admin)
    if msg:
        db_sess.delete(msg)
        db_sess.commit()
    else:
        # abort(403)
        redirect('/login')
    return redirect(f'/msg/{to}')


@app.route('/msg/<int:to>/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_msg(id, to):
    form = MsgForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        msg = db_sess.query(Message).filter(
            Message.id == id).first()  # ((News.user == current_user) | current_user.is_admin)
        if msg:
            if current_user.id > to:
                msg.title = f'{current_user.id}_{to}'
            else:
                msg.title = f'{to}_{current_user.id}'
            form.content.data = msg.content
        else:
            # abort(403)
            redirect('/login')
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        msg = db_sess.query(News).filter(
            Message.id == id).first()  # ((News.user == current_user) | current_user.is_admin)
        if msg:
            if current_user.id > to:
                msg.title = f'{current_user.id}_{to}'
            else:
                msg.title = f'{to}_{current_user.id}'
            msg.content = form.content.data
            db_sess.commit()
            return redirect(f'/msg/{to}')
        else:
            # abort(403)
            redirect('/login')
    return render_template('msg.html', title='Редактирование новости', form=form)


def main():
    app.run()


if __name__ == '__main__':
    main()
