from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, FileField, MultipleFileField
from wtforms import BooleanField, SubmitField, HiddenField
from wtforms.validators import DataRequired


class CommsForm(FlaskForm):
    to = StringField("ToNewsId")
    content = TextAreaField("Содержание")
    submit = SubmitField('Сохранить')
