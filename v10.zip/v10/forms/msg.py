from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField
from wtforms import BooleanField, SubmitField
from wtforms.validators import DataRequired


class MsgForm(FlaskForm):
    # title = StringField('Заголовок', validators=[DataRequired()])
    content = TextAreaField("Текст сообщения", validators=[DataRequired()])
    # is_private = BooleanField("Личное")
    submit = SubmitField('Отправить')